package dataProvider;

import org.testng.annotations.Test;
import org.testng.annotations.Test;
import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
//import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.beust.jcommander.Parameter;

import io.github.bonigarcia.wdm.WebDriverManager;
//inhert or by using data provider
import utils.DataUtils;

public class Basic extends DataUtils {
	//@Parameter({""})
	@Test(dataProvider= "getData", dataProviderClass=DataUtils.class)
	public void Login(String email,String pass){
		//System.err.println("Email:"+data[0]);
		//System.err.println("pass"+ data[1]);
        WebDriverManager.chromedriver().setup();
		ChromeDriver driver = new ChromeDriver();
		driver.get("http://d2ggk2m8z3e33q.cloudfront.net/auth/signin");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		driver.get("http://d2ggk2m8z3e33q.cloudfront.net/auth/signin");
		driver.findElement(By.xpath("//input[@type='email']")).sendKeys(email);
		driver.findElement(By.xpath("//input[@type='password']")).sendKeys(pass);
		driver.findElement(By.xpath("//div[contains(@class,'form-group text-left')]/following-sibling::button[1]")).click();
		String title= driver.getTitle();
		System.out.println("title is"+title);
		//driver.quit();
driver.findElement(By.xpath("//a[@ng-reflect-router-link='/users']//span[1]")).click();
		driver.findElement(By.xpath("//span[text()='Add User ']")).click();
		driver.findElement(By.xpath("//input[@formcontrolname='first_name']")).sendKeys("Automation");
		driver.findElement(By.xpath("//input[@formcontrolname='email_id']")).sendKeys("Automation@gmail.com");
		driver.findElement(By.xpath("//input[@formcontrolname='contact_number']")).sendKeys("2231010001");
		driver.findElement(By.xpath("//input[@formcontrolname='password']")).sendKeys("password");
		driver.findElement(By.xpath("//div[@ng-reflect-ng-switch='true']/following-sibling::div[1]")).click();
		driver.findElement(By.xpath("//mat-option[@role='option']")).click();
		WebElement user = driver.findElement(By.xpath("//span[text()='Add']"));
		JavascriptExecutor executor = (JavascriptExecutor)driver;
		executor.executeScript("arguments[0].click();", user);
	}















}







