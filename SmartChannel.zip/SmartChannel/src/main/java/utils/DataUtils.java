package utils;

import org.testng.annotations.DataProvider;

import dataProvider.Data;

public class DataUtils {
	// to send a certain data we can use indices
	@DataProvider(name="Data",indices= {4})
	public String[][] getData(){
		//String[][] data= new String[2][2];
		String[][] excelData = null;
		try {
			excelData = Data.getExcelData(null);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		/*data[0][0]="superadminuat@gmail.com";
		data [0][1]="password";
		data[1][0]="subadminuat@gmail.com";
		data [1][1]="password";*/
		return excelData;
     }
}
