package utils;
import org.testng.annotations.DataProvider;
import dataProvider.Data;
import dataProvider.EndUserData;
public class EndUserUtils {

	// to send a certain data we can use indices
@DataProvider(name="Data",indices= {0})
public String[][] getData(){
	
String[][] excelData = null;
try {
	excelData = EndUserData.getExcelData(null);
	} catch (Exception e) {
		e.printStackTrace();
		}
		return excelData;
	}
}
