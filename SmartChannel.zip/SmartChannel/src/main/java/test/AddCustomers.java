package test;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;
@Test
public class AddCustomers extends Base1{
	public void Customer() {
 Boolean enabled=driver.findElement(By.xpath("//a[@href='/customersDetails']")).isEnabled();
 System.out.println("Element enabled is :"+enabled);
 driver.findElement(By.xpath("//a[@href='/customersDetails']")).click();
 Boolean selected= driver.findElement(By.xpath("//span[text()=' Add Customer ']")).isSelected();
 System.out.println("Element selected is :"+selected);
 driver.findElement(By.xpath("//span[text()=' Add Customer ']")).click();
 driver.findElement(By.xpath("//input[@formcontrolname='pancard_number']")).sendKeys(null);
 driver.findElement(By.xpath("//input[@formcontrolname='aadhaar_number']")).sendKeys(null);
 driver.findElement(By.xpath("")).sendKeys(null);
 driver.findElement(By.xpath("//input[@formcontrolname='pancard_number']")).sendKeys(null);
 driver.findElement(By.xpath("//input[@formcontrolname='pancard_number']")).sendKeys(null);
 driver.findElement(By.xpath("//input[@formcontrolname='pancard_number']")).sendKeys(null);
 driver.findElement(By.xpath("//input[@formcontrolname='pancard_number']")).sendKeys(null);
 driver.findElement(By.xpath("//input[@formcontrolname='pancard_number']")).sendKeys(null);
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 /*driver.findElement(By.id("mat-input-4")).sendKeys("457945125623");
// driver.findElement(By.xpath("//input[@formcontrolname='customer_code']")).sendKeys("451955");
 driver.findElement(By.id("mat-input-5")).sendKeys("451955");
 driver.findElement(By.xpath("//mat-select[@id='mat-select-1']/div[1]/div[2]/div[1]")).click();
 driver.findElement(By.xpath("//span[text()='Surface']")).click();
 driver.findElement(By.id("mat-input-6")).sendKeys("dera");
 driver.findElement(By.id("mat-input-7")).sendKeys("Address Line1");
 driver.findElement(By.id("mat-input-8")).sendKeys("STreet 1");
 driver.findElement(By.id("mat-input-9")).sendKeys("Volve"); 
 driver.findElement(By.id("mat-input-10")).sendKeys("M&S");
 driver.findElement(By.id("mat-input-11")).sendKeys("Bangalore");
 
 driver.findElement(By.id("mat-input-12")).sendKeys("400075");
 driver.findElement(By.id("mat-input-13")).sendKeys("Karnataka");
 driver.findElement(By.id("mat-input-16")).sendKeys("7877789898");
 driver.findElement(By.id("mat-input-17")).sendKeys("dera@gmail.com");
 //Using JavascriptExecutor to overcome permanent delay in click 
 WebElement element = driver.findElement(By.className("mat-checkbox-inner-container"));
 JavascriptExecutor executor = (JavascriptExecutor)driver;
 executor.executeScript("arguments[0].click();", element);
 WebElement element1 = driver.findElement(By.xpath("//span[text()='Add']"));
 JavascriptExecutor executor1 = (JavascriptExecutor)driver;
executor1.executeScript("arguments[0].click();", element1);
 
 */
 
 
 
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	}}
