package test;

public class NewCreation {

}
