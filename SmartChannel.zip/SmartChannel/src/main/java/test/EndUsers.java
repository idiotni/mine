package test;
//import static org.testng.AssertJUnit.assertTrue;
import org.testng.annotations.Test;

import dataProvider.EndUserData;
import io.github.bonigarcia.wdm.WebDriverManager;


import utils.EndUserUtils;

//import org.testng.asserts.SoftAssert;

import java.io.IOException;
//import com.aventstack.extentreports.util.Assert;
import java.time.Duration;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

@Test
public class EndUsers extends EndUserUtils {
	@Test(dataProvider= "Data", dataProviderClass=EndUserUtils.class)
	
	public void Login(String email,String pass,String pancard,String aadhar,String customercode )throws IOException, InterruptedException {

		WebDriverManager.chromedriver().setup();
		ChromeDriver driver = new ChromeDriver();
		driver.get("http://d2ggk2m8z3e33q.cloudfront.net/auth/signin");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		driver.findElement(By.xpath("//input[@type='email']")).sendKeys(email);
		driver.findElement(By.xpath("//input[@type='password']")).sendKeys(pass);
		driver.findElement(By.xpath("//div[contains(@class,'form-group text-left')]/following-sibling::button[1]")).click();
		String title= driver.getTitle();
		System.out.println("title is"+title);
		WebElement user1 = driver.findElement(By.xpath("//a[@ng-reflect-router-link='/users']"));
		JavascriptExecutor executor1 = (JavascriptExecutor)driver;
		executor1.executeScript("arguments[0].click();", user1);
		//driver.findElement(By.xpath("//span[text()='Users']")).click();
		//driver.findElement(By.linkText("Users")).click();
		 
		WebElement user2 = driver.findElement(By.xpath("//mat-select[@id='mat-select-0']/div[1]/div[2]/div[1]"));
		JavascriptExecutor executor2 = (JavascriptExecutor)driver;
		executor2.executeScript("arguments[0].click();", user2);
		//driver.findElement(By.xpath("//div[@class='mat-select-arrow ng-tns-c186-3']")).click();
		WebElement user = driver.findElement(By.xpath("//mat-option[@ng-reflect-value='100']//span[1]"));
		JavascriptExecutor executor = (JavascriptExecutor)driver;
		executor.executeScript("arguments[0].click();", user);
		//driver.findElement(By.xpath("//mat-option[@ng-reflect-value='100']//span[1]")).click();
		//taken the pick up user account in numbers
		driver.findElement(By.xpath("html[1]/body[1]/app-root[1]/app-admin[1]/div[1]/div[1]/app-esa-user[1]/div[2]/div[1]/app-card[1]/div[1]/div[2]/div[1]/table[1]/tbody[1]/tr[33]/td[7]/a[2]/mat-icon[1]")).click();

		//stale element
		WebElement l = driver.findElement(By.xpath("//span[text()=' Add Customer ']"));
	      l.click();
	      //refresh page
	      driver.navigate().refresh();
	      //fix exception with try−catch block
	      try{
	         l.click();
	      }
	      catch(StaleElementReferenceException e){
	         l = driver.findElement(By.xpath("//span[text()=' Add Customer ']"));
	         l.click();
	         //obtain value entered
	         String s= l.getAttribute("value");
	         System.out.println("Value entered is: " +s);
	      }
	    driver.findElement(By.xpath("//input[@formcontrolname='pancard_number']")).sendKeys(pancard);
		driver.findElement(By.xpath("//input[@formcontrolname='aadhaar_number']")).sendKeys(aadhar);
		driver.findElement(By.xpath("//input[@formcontrolname='customer_code']")).sendKeys(customercode);
	}
		/*WebElement clickAdd = driver.findElement(By.xpath("//span[@class='mat-button-wrapper']//mat-icon[1]"));
		JavascriptExecutor endUser = (JavascriptExecutor)driver;
		endUser.executeScript("arguments[0].click();", clickAdd);*/
		//driver.findElement(By.xpath("//mat-icon[text()='add']")).click();
		
}
