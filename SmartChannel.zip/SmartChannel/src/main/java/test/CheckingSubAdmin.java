package test;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;

import baseClass.Base2;

public class CheckingSubAdmin extends Base2{
	@Test
	public void verfiy() {
		 WebElement searchButton = driver.findElement(By.xpath("//a[@href='/users']"));
			JavascriptExecutor js = (JavascriptExecutor)driver;
			js.executeScript("arguments[0].click()", searchButton);
			WebElement ele = driver.findElement(By.xpath("//div[@ng-reflect-ng-switch='false']/following-sibling::div[1]"));
			JavascriptExecutor executor = (JavascriptExecutor)driver;
			executor.executeScript("arguments[0].click();", ele);
		/*	WebElement ele1 = driver.findElement(By.xpath("//span[text()=' 100 ']"));
			JavascriptExecutor executor1 = (JavascriptExecutor)driver;
			executor.executeScript("arguments[0].click();", ele);*/
			driver.findElement(By.xpath("//span[text()=' 100 ']")).click();
			driver.findElement(By.xpath("html[1]/body[1]/app-root[1]/app-admin[1]/div[1]/div[1]/app-esa-user[1]/div[2]/div[1]/app-card[1]/div[1]/div[2]/div[1]/table[1]/tbody[1]/tr[38]/td[5]/mat-icon[1]")).click();
	}
}
