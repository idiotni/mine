package test;
import java.time.Duration;
import java.util.NoSuchElementException;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;
import baseClass.BaseClass;
import io.github.bonigarcia.wdm.WebDriverManager;
import utils.DataUtils;
import utils.ExcelTest;
@Test
public class SubAdmin extends DataUtils{
	@Test(dataProvider= "Data", dataProviderClass=DataUtils.class)
	public void Login(String data1[]){
		System.err.println("Email:"+data1[1]);
		System.err.println("pass"+ data1[2]);
		WebDriverManager.chromedriver().setup();
		ChromeDriver driver = new ChromeDriver();
		driver.get("http://d2ggk2m8z3e33q.cloudfront.net/auth/signin");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		//driver.get("http://d2ggk2m8z3e33q.cloudfront.net/auth/signin");
		driver.findElement(By.xpath("//input[@type='email']")).sendKeys(data1[1]);
		driver.findElement(By.xpath("//input[@type='password']")).sendKeys(data1[2]);
		driver.findElement(By.xpath("//div[contains(@class,'form-group text-left')]/following-sibling::button[1]")).click();
		String title= driver.getTitle();
		System.out.println("title is"+title);

		//using for element interception
		WebElement searchButton = driver.findElement(By.xpath("//a[@href='/users']"));
		JavascriptExecutor js = (JavascriptExecutor)driver;
		js.executeScript("arguments[0].click()", searchButton);
		WebElement user = driver.findElement(By.xpath("//mat-icon[contains(@class,'mat-icon notranslate')]"));
		JavascriptExecutor executor = (JavascriptExecutor)driver;
		executor.executeScript("arguments[0].click();", user);
		// driver.findElement(By.xpath("(//button[contains(@class,'mat-focus-indicator button-add')]//span)[1]")).click();
		//driver.findElement(By.xpath("//button[contains(@class,'mat-focus-indicator button-add')]")).click();
		driver.findElement(By.xpath("//input[@formcontrolname='esa_id']")).sendKeys("E28452");
		driver.findElement(By.xpath("//input[@formcontrolname='password']")).sendKeys("password");
		driver.findElement(By.xpath("//input[@formcontrolname='first_name']")).sendKeys("EsaUser1");
		driver.findElement(By.xpath("//input[@formcontrolname='contact_number']")).sendKeys("1010102020");
		driver.findElement(By.xpath("//input[@formcontrolname='email_id']")).sendKeys("Automation@gmailcom");
		driver.findElement(By.xpath("//input[@formcontrolname='address_1']")).sendKeys("Address Line1");
		driver.findElement(By.xpath("//input[@formcontrolname='address_2']")).sendKeys("Line2");
		driver.findElement(By.xpath("//input[@formcontrolname='city']")).sendKeys("Bangalore");
		driver.findElement(By.xpath("//input[@formcontrolname='state']")).sendKeys("Karnataka");
		driver.findElement(By.xpath("//input[@formcontrolname='country']")).sendKeys("India");
		driver.findElement(By.xpath("//input[@formcontrolname='country_code']")).sendKeys("IN");
		driver.findElement(By.xpath("//input[@formcontrolname='postal_code']")).sendKeys("400075");
		driver.findElement(By.xpath("//input[@formcontrolname='license_key']")).sendKeys("eedc799c53d9b3aed8af45f2408791");
		driver.findElement(By.xpath("//input[@formcontrolname='area_code']")).sendKeys("BOM");
		driver.findElement(By.xpath("//input[@formcontrolname='login_id']")).sendKeys("BOM00008");
		driver.findElement(By.xpath("//input[@formcontrolname='pu_code']")).sendKeys("9248");
		driver.findElement(By.xpath("//input[@formcontrolname='pu_name']")).sendKeys("agent");
		//driver.findElement(By.xpath("//div[@class='mat-select-arrow-wrapper ng-tns-c186-91']//div[1]")).click();
		try {
			driver.findElement(By.xpath("//div[@ng-reflect-ng-switch='true']/following-sibling::div[1]")).click();

		}
		catch(NoSuchElementException e) {
			System.out.println("Handled NoSuchElementException");
		}
		driver.findElement(By.xpath("(//mat-pseudo-checkbox[contains(@class,'mat-pseudo-checkbox mat-option-pseudo-checkbox')])[2]")).click();
		//WebElement Add = driver.findElement(By.xpath("//span[text()='Add']"));
		//JavascriptExecutor exe = (JavascriptExecutor)driver;
		//exe.executeScript("arguments[0].click();", Add);
		driver.quit();




	}


}
