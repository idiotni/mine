package test;
import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;
import baseClass.Base2;
import io.github.bonigarcia.wdm.WebDriverManager;
import utils.DataUtils;
public class SuperAdmin extends DataUtils{
@Test(dataProvider= "Data",dataProviderClass=DataUtils.class)
	public void Login(String data3[]){
		System.err.println("Email:"+data3[2]);
		System.err.println("pass"+ data3[3]);
		WebDriverManager.chromedriver().setup();
		ChromeDriver driver = new ChromeDriver();
		driver.get("http://d2ggk2m8z3e33q.cloudfront.net/auth/signin");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		//driver.get("http://d2ggk2m8z3e33q.cloudfront.net/auth/signin");
		driver.findElement(By.xpath("//input[@type='email']")).sendKeys(data3[2]);
		driver.findElement(By.xpath("//input[@type='password']")).sendKeys(data3[3]);
		driver.findElement(By.xpath("//div[contains(@class,'form-group text-left')]/following-sibling::button[1]")).click();
		String title= driver.getTitle();
		System.out.println("title is"+title);
		WebElement User = driver.findElement(By.xpath("//span[text()='Users']"));//driver.findElement(By.xpath("//a[@href='/users']"))
		JavascriptExecutor js = (JavascriptExecutor)driver;
		js.executeScript("arguments[0].click()", User);
		WebElement Adduser = driver.findElement(By.xpath("//mat-icon[contains(@class,'mat-icon notranslate')]"));
		JavascriptExecutor executor = (JavascriptExecutor)driver;
		executor.executeScript("arguments[0].click();", Adduser);
		driver.findElement(By.xpath("//input[@formcontrolname='first_name']")).sendKeys("lomi0n");
		driver.findElement(By.xpath("//input[@formcontrolname='password']")).sendKeys("password");
		driver.findElement(By.xpath("//input[@formcontrolname='contact_number']")).sendKeys("5686666266");
		driver.findElement(By.xpath("//input[@formcontrolname='email_id']")).sendKeys("lomon212@gmail.com");
		//WebElement Add = driver.findElement(By.xpath("//span[text()='Add']"));
		//JavascriptExecutor exel = (JavascriptExecutor)driver;
		//exel.executeScript("arguments[0].click();", Add);
		driver.quit();
	}   

}	

