package test;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;
import utils.DataUtils;

public class AddBulkCustomers extends DataUtils{
	@Test(dataProvider= "Data", dataProviderClass=DataUtils.class)
	public void Login(String data[]){
		System.err.println("Email:"+data[0]);
		System.err.println("pass"+ data[1]);
		WebDriverManager.chromedriver().setup();
		ChromeDriver driver = new ChromeDriver();
		//for Login
		driver.get("http://d2ggk2m8z3e33q.cloudfront.net/auth/signin");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		//driver.get("http://d2ggk2m8z3e33q.cloudfront.net/auth/signin");
		driver.findElement(By.xpath("//input[@type='email']")).sendKeys(data[0]);
		driver.findElement(By.xpath("//input[@type='password']")).sendKeys(data[1]);
		driver.findElement(By.xpath("//div[contains(@class,'form-group text-left')]/following-sibling::button[1]")).click();
		String title= driver.getTitle();
		System.out.println("title is"+title);
		Boolean enabled=driver.findElement(By.xpath("//span[text()='Customers']")).isEnabled();
		System.out.println("Element enabled is :"+enabled);
		driver.findElement(By.xpath("//span[text()='Customers']")).click();
		Boolean selected= driver.findElement(By.xpath("//span[text()=' Bulk Upload Customer ']")).isSelected();
		System.out.println("Element selected is :"+selected);
		driver.findElement(By.xpath("//span[text()=' Bulk Upload Customer ']")).click();
		

	}
}
