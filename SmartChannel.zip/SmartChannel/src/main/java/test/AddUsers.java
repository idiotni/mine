package test;

import org.testng.Assert;
//import static org.testng.AssertJUnit.assertTrue;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import io.github.bonigarcia.wdm.WebDriverManager;
import utils.DataUtils;
//import org.testng.asserts.SoftAssert;

import java.io.File;
import java.io.IOException;

//import com.aventstack.extentreports.util.Assert;

import java.time.Duration;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.io.FileHandler;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

@Test
public class AddUsers extends DataUtils {
	@Test(dataProvider= "Data", dataProviderClass=DataUtils.class)
	public void Login(String email,String pass,String firstName,String lastName,String emailid,String contactNo,String password) throws IOException {

		WebDriverManager.chromedriver().setup();
		ChromeDriver driver = new ChromeDriver();
		driver.get("http://d2ggk2m8z3e33q.cloudfront.net/auth/signin");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		driver.findElement(By.xpath("//input[@type='email']")).sendKeys(email);
		driver.findElement(By.xpath("//input[@type='password']")).sendKeys(pass);
		driver.findElement(By.xpath("//div[contains(@class,'form-group text-left')]/following-sibling::button[1]")).click();
		String title= driver.getTitle();
		System.out.println("title is"+title);
		driver.findElement(By.linkText("Users")).click();
		//WebDriverWait wait2 = new WebDriverWait(driver, 10);
		//wait2.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[text()='Users']")));
		//driver.findElement(By.xpath("//perfect-scrollbar[@id='nav-ps-flat-able']/div[1]/div[1]/div[1]/ul[1]/app-nav-group[2]/app-nav-item[2]/li[1]/a[1]")).click();
		//driver.findElement(By.linkText("Users")).click();
		//driver.findElement(By.xpath("//span[text()='Users']")).click();
		WebElement user1 = driver.findElement(By.xpath("//mat-icon[text()='add']"));
		JavascriptExecutor executor1 = (JavascriptExecutor)driver;
		executor1.executeScript("arguments[0].click();", user1);
		//driver.findElement(By.xpath("//mat-icon[text()='add']")).click();
		driver.findElement(By.xpath("//input[@formcontrolname='first_name']")).sendKeys(firstName);
		driver.findElement(By.xpath("//input[@formcontrolname='last_name']")).sendKeys(lastName);
		driver.findElement(By.xpath("//input[@formcontrolname='email_id']")).sendKeys(emailid);
		driver.findElement(By.xpath("//input[@formcontrolname='contact_number']")).sendKeys(contactNo);
		driver.findElement(By.xpath("//input[@formcontrolname='password']")).sendKeys(password);
		WebElement buttonElement =driver.findElement(By.xpath("//div[@ng-reflect-ng-switch='true']/following-sibling::div[1]"));
		Boolean isbuttonEnable=buttonElement.isEnabled();
		System.out.println("All the details are given"+isbuttonEnable);
		//driver.findElement(By.xpath("//div[@ng-reflect-ng-switch='true']/following-sibling::div[1]")).click();
		Boolean enabled=driver.findElement(By.xpath("//mat-select[@id='mat-select-1']/div[1]/div[2]/div[1]")).isEnabled();
		System.out.println("add user creation is done successfully :"+enabled);
		driver.findElement(By.xpath("//mat-select[@id='mat-select-1']/div[1]/div[2]/div[1]")).click();
		driver.findElement(By.xpath("//span[text()='DomesticPriority']")).click();
		WebElement user = driver.findElement(By.xpath("//span[text()='Add']"));
		JavascriptExecutor executor = (JavascriptExecutor)driver;
		executor.executeScript("arguments[0].click();", user);
		try {
			WebDriverWait wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.alertIsPresent());
			Alert alert = driver.switchTo().alert();
			System.out.println(alert.getText());
			alert.accept();
			Assert.assertTrue(alert.getText().contains("user"));
		} catch (Exception e) {

		}
		//click the full details
		WebElement user2 = driver.findElement(By.xpath("//mat-select[@id='mat-select-0']/div[1]/div[2]/div[1]"));
		JavascriptExecutor executor2 = (JavascriptExecutor)driver;
		executor2.executeScript("arguments[0].click();", user2);
		//driver.findElement(By.xpath("//div[@class='mat-select-arrow ng-tns-c186-3']")).click();
		driver.findElement(By.xpath("//span[text()=' 100 ']")).click();
		//click the add users which is created
		WebElement user3 = driver.findElement(By.xpath("//mat-select[@id='mat-select-0']/div[1]/div[2]/div[1]"));
		JavascriptExecutor executor3 = (JavascriptExecutor)driver;
		executor3.executeScript("arguments[0].click();", user3);
		File firstSrc=driver.getScreenshotAs(OutputType.FILE);
		File dest=new File("./snaps/img.png");
		FileHandler.copy(firstSrc, dest);
		
		//driver.findElement(By.xpath("//span[text()='Logout']")).click();
		//driver.findElement(By.xpath("//button[@color='primary']")).click();


		//driver.quit();


	}
}