package test;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;
import utils.DataUtils;

public class AddBulkUser extends DataUtils {
	@Test(dataProvider= "Data", dataProviderClass=DataUtils.class)
	public void Login(String data[]){
		System.err.println("Email:"+data[0]);
		System.err.println("pass"+ data[1]);
		WebDriverManager.chromedriver().setup();
		ChromeDriver driver = new ChromeDriver();
		//for Login
		driver.get("http://d2ggk2m8z3e33q.cloudfront.net/auth/signin");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		//driver.get("http://d2ggk2m8z3e33q.cloudfront.net/auth/signin");
		driver.findElement(By.xpath("//input[@type='email']")).sendKeys(data[0]);
		driver.findElement(By.xpath("//input[@type='password']")).sendKeys(data[1]);
		driver.findElement(By.xpath("//div[contains(@class,'form-group text-left')]/following-sibling::button[1]")).click();
		String title= driver.getTitle();
		System.out.println("title is"+title);

		//Creating a BulkUsers
		WebElement element1 = driver.findElement(By.xpath("//a[@href='/users']"));
		JavascriptExecutor executor1 = (JavascriptExecutor)driver;
		executor1.executeScript("arguments[0].click();", element1);
		//driver.findElement(By.xpath("//span[text()='Users']")).click();
		driver.findElement(By.xpath("//span[text()[normalize-space()='Bulk Upload User']]")).click();
		//upload a excel sheet while save in test data and pass in it
		WebElement upload=driver.findElement(By.cssSelector("input#file"));
		//upload.sendKeys("D:\\SmartChannel\\test-data\\login.xlsx");
		upload.sendKeys("E:\\SmartChannel\\test-data\\pickup_template.csv");
		WebElement element = driver.findElement(By.xpath("//button[@type='submit']"));
		JavascriptExecutor executor = (JavascriptExecutor)driver;
		executor.executeScript("arguments[0].click();", element);
       //checking the if bulkUsers is created
	/*	WebElement ele = driver.findElement(By.xpath("//mat-select[@id='mat-select-0']/div[1]/div[2]/div[1]"));
		JavascriptExecutor exec = (JavascriptExecutor)driver;
		exec.executeScript("arguments[0].click();", ele);
		WebElement ele1= driver.findElement(By.xpath("//span[text()=' 100 ']"));
		JavascriptExecutor exec1 = (JavascriptExecutor)driver;
		exec1.executeScript("arguments[0].click();", ele1);*/
        //for logout
		driver.findElement(By.xpath("//span[text()='Logout']")).click();
		driver.findElement(By.xpath("//span[text()='Yes']")).click();
		driver.close();
	}
}
