package baseClass;
import java.io.IOException;

import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class Data1 {
	public static void main(String[] args) throws IOException {
		String file="D:\\SmartChannel\\test-data\\login.xlsx";
		XSSFWorkbook wb=new XSSFWorkbook(file);
		XSSFSheet sheet=wb.getSheetAt(0);
		int row=sheet.getFirstRowNum();
		int pnor=sheet.getPhysicalNumberOfRows();
		short cellnumber=sheet.getRow(0).getFirstCellNum();
		for (int i = 1; i <=row; i++) {
			XSSFRow row1 = sheet.getRow(i);
			for (int j= 0; j < cellnumber; j++) {
				XSSFCell cell = row1.getCell(j);
				String value = cell.getStringCellValue();
				System.out.println(value);
			
			} 
		}
		
	}
}