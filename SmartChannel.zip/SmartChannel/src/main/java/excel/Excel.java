package excel;

import java.io.File;
import java.io.FileInputStream;

import org.apache.poi.sl.usermodel.Sheet;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class Excel {
	
		public static void main(String[] args) throws Exception {
			File excelFile = new File("D:\\SmartChannel\\test-data\\login.xlsx");
			//if file is there it shows exists
			System.out.println(excelFile.exists());
			FileInputStream file = new 	FileInputStream(excelFile);
			// convert raw data from excel format
			//@SuppressWarnings("resource")
			XSSFWorkbook Workbook = new XSSFWorkbook(file);
			// workbook into sheet
			XSSFSheet sheet = Workbook.getSheet("Login");
			//to check how many number rows in sheet
			sheet.getPhysicalNumberOfRows();
			//Workbook.close();
			//file.close();

	
	
	}
}


