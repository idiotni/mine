package dataProvider;

import org.testng.annotations.Test;

public class BasicTest {

  @Test
  public void LoginTest() {
    throw new RuntimeException("Test not implemented");
  }
}
