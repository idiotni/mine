package screens;
import org.openqa.selenium.By;
import hook.BasePage;

public class Login extends BasePage {
	//public Login typeUserName(String esauat@gmailcom) {
		//driver.findElement(By.xpath("").sendKeys(esauat@gmailcom);
	//	return this;
	//}

}
