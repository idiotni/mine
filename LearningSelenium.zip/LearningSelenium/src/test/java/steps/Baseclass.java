package steps;

import org.openqa.selenium.chrome.ChromeDriver;

public class Baseclass {
public static ChromeDriver driver;
}
