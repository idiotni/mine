package Cucumberday1;

public class CucumberClass {

	public static void main(String[] args) {
		
	}

}
