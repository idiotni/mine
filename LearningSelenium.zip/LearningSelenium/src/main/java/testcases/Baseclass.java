package testcases;

public class Baseclass {

}
