package testcases;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

import io.github.bonigarcia.wdm.WebDriverManager;

public class Createcontact {
	public static void main(String[] args) {
		WebDriverManager.chromedriver().setup();
		ChromeDriver driver = new ChromeDriver();
	  	driver.get("http://leaftaps.com/opentaps/control/main");
	  	driver.manage().window().maximize();
	  	WebElement elementUsername = driver.findElement(By.id("username"));
	  	elementUsername.sendKeys("Demosalesmanager");
	  	WebElement elementPassword = driver.findElement(By.id("password"));
	  	elementPassword.sendKeys("crmsfa");
	  	driver.findElement(By.className("decorativeSubmit")).click();
	  	driver.findElement(By.className("crmsfa")).click();	
		driver.findElement(By.linkText("Leads")).click();
		driver.findElement(By.linkText("Create Contact")).click();
		WebElement elementFirstname=driver.findElement(By.id("firstNameField"));
		elementFirstname.sendKeys("riya");
		driver.findElement(By.id("lastNameField")).sendKeys("s");
		driver.findElement(By.id("createContactForm_firstNameLocal")).sendKeys("");
		driver.findElement(By.id("createContactForm_lastNameLocal")).sendKeys("");
		driver.findElement(By.id("createContactForm_personalTitle")).sendKeys("fresher");
		driver.findElement(By.id("createContactForm_departmentName")).sendKeys("EEE");
		driver.findElement(By.id("createContactForm_primaryEmail")).sendKeys("rinusumi0905@gmail.com");
		WebElement state = driver.findElement(By.id("createContactForm_generalStateProvinceGeoId"));
		Select obj = new Select(state);
		obj.selectByVisibleText("New York");
		driver.findElement(By.name("submitButton")).click();
}
}
