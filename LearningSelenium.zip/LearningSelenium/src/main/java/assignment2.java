
public class assignment2 {

}
