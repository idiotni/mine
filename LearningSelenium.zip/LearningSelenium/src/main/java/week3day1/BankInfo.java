package week3day1;

public class BankInfo {
public void saving() {
	System.out.println("saving for student will be 50000");
}
public void fixed() {
	System.out.println("fixed amount will be 5000");
}
public void deposit() {
	System.out.println("deposit amount in my account 30000");
}
}

