package week3day1;
// inside a interface you allowed have static and final
//we cannot create private variables in interface
public interface RBI {
public int cardno=123;//this defined by rbi
int pinCount=4;
public void openSavingAcc();//allow method signature not allow method method body
/***
 * this method performance transfer fund for the given debitacc to the given credit ac 
 * using a valid banking transaction
 * the amount mentioned can be debit from the creditor and deposit to the depositer
 * the insufficient fund in the debit acc may attract charge
 * @param debitacc-12 digitacc number
 * @param creditacc-12 digitacc number
 * @param amount-greater than 0
 * @return true-when the transfer is completed
 * false -insufficient fund occurs  //this method doesnot have method body is called abstract
 */
//this method doesnot have method body is called abstract

public boolean transferFund(int debitacc,int creditacc, int chqno,int amount);

}
