package week3day1;

public class SBI implements RBI{

	public void openSavingAcc() {
		// TODO Auto-generated method stub
		
	}

	public boolean transferFund(int debitacc, int creditacc, int chqno, int amount) {
		// TODO Auto-generated method stub
		return false;
	}
	public void provideCreditCard() {
	
	}
// doesnot belong to interface this method owned by sbi bank 
	/*public void openSavingAcc() {
		// TODO Auto-generated method stub
		System.out.println("saving ac with min 500 as balance");
	}
	public void personalLoan() {
		System.out.println("personalLoan");
	}
	public static void main(String[]args) {
	SBI bank=new SBI();
	bank.openSavingAcc();
	bank.personalLoan();//restricted the obj to bring only given object we can use scope
}*/
	
}
