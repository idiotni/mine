package week3day1;

public class Bank {

 	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
//SBI bank=new SBI();
RBI bank =new SBI();
bank.openSavingAcc();
//bank.provideCreditCard();//restrict the scope the variable
//bank.transferFund(int debitacc, int creditacc, int chqno, int amount)

	}

}
