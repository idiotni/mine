package week3day1;

public class Audi extends Car{
	public void applybrake() {
		System.out.println("apply ABS brake-AUdi");
	}
	public void getBrake() {
		this.applybrake();
	}
	public void getSuperBrake() {
		super.applyBrake();
		//super is keyword to call a super class or main class
	}
public void autoPark() {
	System.out.println("autoPark-audi");
}
}
