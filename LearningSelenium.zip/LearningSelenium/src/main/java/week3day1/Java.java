package week3day1;

public class Java {
	public void java() {

}
}