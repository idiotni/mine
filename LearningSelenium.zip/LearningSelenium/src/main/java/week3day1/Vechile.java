package week3day1;

public class Vechile {
public void applyBrake() {
System.out.println("apply brake -vechicle");
}
public void soundHorn() {
	System.out.println("sound horn-vechicle");
}
}

