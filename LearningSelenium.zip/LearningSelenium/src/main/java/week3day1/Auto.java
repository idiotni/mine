package week3day1;

public class Auto extends Vechile {
public void resetMeter() {
	this.applyBrake();
	//*this* is keyword is equal to creating a new object for the current class
	System.out.println("reset meter-auto");
}
}
