package week3day1;

public class Myvechile {
	int num=1234;
	public void printMyVechileName() {
		System.out.println("Mercedes-a class limousine");
	}
	public void getCarName() {
		
		this.printMyVechileName();
		//int num1 =this.num;
	}
public static void main(String[]args) {
	//when we create a static variable the value of static variable remains same 
	
Vechile vechile =new Vechile();
	Car car = new Car();
	Audi audi= new Audi();
	vechile.applyBrake();
	vechile.soundHorn();
	  
	car.applyBrake();
	car.soundHorn();
	car.openDoor();
	
	audi.applyBrake();
	audi.soundHorn();
	audi.autoPark();
	audi.getSuperBrake();
			
	}
}
