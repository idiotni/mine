package week3day1;

public class LearnStatic {
	public int a=5;
	public static int b=6;
	final int c=5;
// VAR a is stored in heed memory
	//VAR b is stored in sat or class memory
	// does not accessible memory
	public void getNo() {
		System.out.println("7");
	}
	public static void getName() {
		System.out.println("sss");
		
	}
	public void incnumber() {
		a=a+5;
		//non static member value
	}
	public void incStatic() {
		LearnStatic.b=LearnStatic.b+5;
		//static member value
	}
public static void main(String[] args) {
LearnStatic obj=new	LearnStatic();
System.out.println(obj.a);
obj.incnumber();
System.out.println(obj.a);
System.out.println(b);
obj.incStatic();
LearnStatic obj1= new LearnStatic();
System.out.println(obj1.a);
obj1.incStatic();
System.out.println(b);

//in static the value will incremented and saved
//static methods cannot be over ridden in subclass
/*obj.getNo();
LearnStatic.getName();
System.out.println(obj.a);
System.out.println(LearnStatic.b);*/
}
}
