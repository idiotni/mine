package week3day1;

public interface Language {
	

}
