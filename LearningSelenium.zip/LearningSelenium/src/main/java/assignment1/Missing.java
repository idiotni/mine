package assignment1;
public class Missing {
public static void main(String[] args) {
		int[]array= {2,4,6,8,9};
		int sum=0;
		for(int i=0;i<array.length;i++) {
		sum=sum+array[i];
	   }
	    System.out.println(sum);	
	    int sum1=1;
		for(int j=1;j<=9;j++) {
			 sum1=sum1+j;
		}
		System.out.println(sum1);
	    System.out.println("missing number is"+(sum1-sum));

			}
	
		 }
   
