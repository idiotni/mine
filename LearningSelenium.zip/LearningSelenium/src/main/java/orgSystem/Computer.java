package orgSystem;

public class Computer {
	public static void computerModel() {
		System.out.println("asus intel i5");
}
	
}
