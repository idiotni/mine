package week3.day2;

import java.util.Collection;
import java.util.LinkedHashMap;

import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
public class LearnMap {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
// in map we can store <emplno,name>this is one data or entry of data
	Map<Integer,String> map = new LinkedHashMap<Integer,String>();
	map.put(1200,"sin");
	map.put(1201,"suli");
	map.put(1202,"sangavi");
	map.put(201,"liva");
	map.remove(1200);
	map.containsKey(1201);
	System.out.println(map);
	System.out.println(map.containsKey(1201));
	Set<Entry<Integer,String>> entryset=map.entrySet();
	for (Entry<Integer,String> eachEntry:entryset) {
		System.out.println(eachEntry.getKey()+"->"+eachEntry);
		
	}
	       Collection<String> values=map.values();
	             Set<Integer> keys=map.keySet();
	             for(Integer eachKey: keys) {
	            	 String value =map.get(eachKey);
	            	System.out.println(eachKey+"->"+eachKey);
	             }

	System.out.println(keys);
	}
	

}
