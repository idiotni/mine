package week3.day2;

//import java.util.ArrayList;
//import java.util.List;
import java.util.Set;
import java.util.LinkedHashSet;

public class Duplicate {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String txt="PaypalIndia";
		char[] array=txt.toCharArray();
		Set<Character> Charset=new LinkedHashSet<Character>();
		Set<Character> dupCharset=new LinkedHashSet<Character>();
		 for (int i=0;i<array.length;i++) {
		      if(Charset.add(array[i])) {
		    	  }
		      else {
		    	  dupCharset.add(array[i]);
		      }
		 }
		 
		
	/*	for(Character character:Charset) {
	    	 if (Charset.contains(character){
	    	  
	    
	    	 }*/
	    	  
		} 
		
	}




