package week3.day2;

import java.util.ArrayList;
import java.util.List;
//import java.util.HashSet;
//import java.util.LinkedHashSet;
import java.util.Set;
import java.util.TreeSet;
public class LearnSet {

	public static void main(String[] args) {
		// set is an interface ,may/may not maintain the insertion
//Set<String> names=new LinkedHashSet<String>();
	//	Set<String> names=new HashSet<String>();
		Set<String> names=new TreeSet<String>();
names.add("sss");
boolean add =names.add("shree");
System.out.println(add);
names.add("savi");
names.add("simmy");
boolean add1=names.add("shree");
System.out.println(add1);
System.out.println(names);
//retrive a value in a set, add value in set
// 2nd way
for(String eachName:names) {
System.out.println(eachName);
	}
names.clear();
names.isEmpty();
List<String>list = new ArrayList<String>(names);// 1st way
names.addAll(names);
}
}
