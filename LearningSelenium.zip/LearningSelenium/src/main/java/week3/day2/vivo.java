package week3.day2;

public interface vivo {
public void spacialAudio();
public void dualCamera();
}
