package week3.day2;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
public class LEARNArrays {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String [] Name=new String[10];
        List<String>list = new ArrayList<String>();
        list.add("sss");
        list.add("shree");
        list.add("mia");
        list.add("ria");
        list.add("ria");
        list.add("mia");
        list.add(2, "nia");//method overloading//add 2 elements will be inserted between the given value
        list.set(4, "riyana");//by using set update to the current name
        list.remove("mia");// remove a first duplicate 
        System.out.println(list);
        System.out.println(list.get(4));//get is value to retrieve 
       System.out.println(list.contains("anu"));//help us to find particular value in the list
       // remove all the list method called clear
       System.out.println(list.size());
       //list.clear();
       System.out.println(list.isEmpty());//this is will give boolean 
       for (int i=0;i<list.size();i++) {
       System.out.println(list.get(i));
       }// can go bi directional
       Collections.sort(list);//ascending sort
       Collections.reverse(list);//descending sort
       for(String eachName:list) {
    	   System.out.println(eachName);//iterates this value
    	 // form top to bottom 
    	 //list.spliterator(); the split the value
       }
       
	}

}
