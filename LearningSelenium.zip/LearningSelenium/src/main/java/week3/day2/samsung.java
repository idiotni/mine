package week3.day2;

public interface samsung {
	public void spacialAudio();
	public void dualCamera();
}
