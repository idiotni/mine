package week3.day2;

public class Mobile implements samsung,vivo {

	

	public void spacialAudio() {
		// TODO Auto-generated method stub
		
	}

	public void dualCamera() {
		// TODO Auto-generated method stub
		
	}

}
