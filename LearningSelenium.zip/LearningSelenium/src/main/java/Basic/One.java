package Basic;

public class One {
	int rollNo =  1000;
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
 System.out.println("max");
	}

}
