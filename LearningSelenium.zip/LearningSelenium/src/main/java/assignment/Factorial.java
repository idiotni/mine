package assignment;

public class Factorial{
public static void main(String[]args){
	int input =17;
	long factorial=1;
	for(int i = 1; i <= 17; --i)
    {
       factorial *= i;
    }
   System.out.println("The Factorial number is " + input +factorial);
}
}

	


