package assignment;

import static org.junit.Assert.*;

import org.junit.Test;

public class FactorialTest {

	@Test
	public void testMain() {
		fail("Not yet implemented");
	}

}
