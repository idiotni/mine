package w4day2;

import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;


import org.openqa.selenium.By;
import org.openqa.selenium.WindowType;
import org.openqa.selenium.chrome.ChromeDriver;


import io.github.bonigarcia.wdm.WebDriverManager;

public class Window {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		WebDriverManager.chromedriver().setup();
		ChromeDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://www.leafground.com/pages/Window.html");
		//we cannot find a locators for window .cann't find a id or name
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
	    //there are 2 methods 1.method
		String WindowHandle=driver.getWindowHandle();
		System.out.println(WindowHandle);//get a randome value
	// printout a randome no is keep changing while exceuting
		driver.findElement(By.id("home")).click();
		Set<String>WindowHandles=	driver.getWindowHandles();//open the tab on the current session
	    //if we get a new window we have to do getwindow handle
       // iterate a multiple window
		for(String eachWindow:WindowHandles) {
			driver.switchTo().window(eachWindow);
			driver.getCurrentUrl();
			break;
		}
		//update a window
		driver.switchTo().newWindow(WindowType.WINDOW);
        //whatever we are storing that as to be unique value is set
		List<String>list=new ArrayList<String>(WindowHandles);
		String secWindow=list.get(1);//refference of second window
		driver.switchTo().window(secWindow);//switching to 2 window using the ref
		System.out.println(driver.getCurrentUrl());
		driver.switchTo().window(list.get(0));//switching to 1window 
		//navigate to 1window
		System.out.println(driver.getCurrentUrl());
		//close the all open operation 
		
		driver.quit();
		
	    
	
	}
	
	
	

}
