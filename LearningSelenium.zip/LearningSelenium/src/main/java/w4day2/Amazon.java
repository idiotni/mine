package w4day2;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class Amazon {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		WebDriverManager.chromedriver().setup();
		ChromeDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get(" https://www.amazon.in/");
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
	    WebElement search= driver.findElement(By.id("twotabsearchtextbox"));
	    search.sendKeys("oneplus 8 pro");
	   driver.findElement(By.id("nav-search-submit-button")).click();
	   Thread.sleep(2000);
	   driver.findElement(By.xpath("//span[@class='a-price-whole']")).click();
	   String window=driver.getWindowHandle();
	   driver.findElement(By.xpath("//span[contains(@class,'a-size-medium a-color-base')]")).click();
	   String price=driver.findElement(By.xpath("//div[@id='corePrice_desktop']/div[1]/table[1]/tbody[1]/tr[2]/td[2]/span[1]/span[2]")).getText();
	   System.out.println(price);
	  String rating=driver.findElement(By.xpath("//i[contains(@class,'a-icon a-icon-star')]")).getText();
	  System.out.println(rating);
	   
	/*	1.Load the uRL https://www.amazon.in/
			2.search as oneplus 9 pro 
			3.Get the price of the first product
			4. Print the number of customer ratings for the first displayed product
			5. click on the stars 
			6. Get the percentage of ratings for the 5 star.
			7. Click the first text link of the first image
			8. Take a screen shot of the product displayed
			9. Click 'Add to Cart' button
			10. Get the cart subtotal and verify if it is correct*/
	}

}
