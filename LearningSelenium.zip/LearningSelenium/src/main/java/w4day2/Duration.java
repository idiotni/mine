package w4day2;

public class Duration {

	public static java.time.Duration ofSeconds(int i) {
		// TODO Auto-generated method stub
		return null;
	}

}
