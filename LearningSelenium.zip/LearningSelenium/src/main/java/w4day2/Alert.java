package w4day2;

import java.time.Duration;
import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class Alert {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		WebDriverManager.chromedriver().setup();
		ChromeDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://www.leafground.com/pages/Alert.html");
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
		driver.findElement(By.xpath("//button[text()='Prompt Box']")).click();
		//driver.findElement(By.xpath("//button[text()='Confirm Box']")).click();
		org.openqa.selenium.Alert alert=driver.switchTo().alert();
		String txt=alert.getText();
		System.out.println(txt);// get a text form alert box
		alert.sendKeys("sss");//only for prompt box
		alert.accept();//postive click
		//alert.dismiss();// negative alert
		
	}

	public void accept() {
		// TODO Auto-generated method stub
		
	}

	
		// TODO Auto-generated method stub
		
	}

	

