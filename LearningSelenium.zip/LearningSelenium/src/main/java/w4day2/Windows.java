package w4day2;

import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.WindowType;
import org.openqa.selenium.chrome.ChromeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class Windows {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		WebDriverManager.chromedriver().setup();
		ChromeDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://www.leafground.com/pages/Window.html");
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
	
		driver.findElement(By.id("home")).click();
		Set<String>WindowHandles=	driver.getWindowHandles();
		List<String>list=new ArrayList<String>(WindowHandles);
		for(String eachWindow:WindowHandles) {
			driver.switchTo().window(eachWindow);
			driver.getCurrentUrl();
			break;
		}
		driver.switchTo().newWindow(WindowType.WINDOW);
		String secWindow=list.get(1);
		driver.switchTo().window(secWindow);
		System.out.println(driver.getCurrentUrl());
		System.out.println(driver.getTitle());
		driver.close();
		driver.switchTo().window(list.get(0));
		System.out.println(driver.getCurrentUrl());
		System.out.println(driver.getTitle());
	
		
		
	
		
	}

}
