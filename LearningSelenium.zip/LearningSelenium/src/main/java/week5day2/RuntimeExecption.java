package week5day2;

public class RuntimeExecption extends Exception {

}
