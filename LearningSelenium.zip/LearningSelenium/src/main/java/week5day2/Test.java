package week5day2;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Parameters;

import io.github.bonigarcia.wdm.WebDriverManager;

public class Test {
public ChromeDriver driver;
@Parameters({"url","username","password"})
@BeforeMethod
public void preconditions(String username,String password,String url){
	WebDriverManager.chromedriver().setup();
	driver=new ChromeDriver();
	driver.get("http://leaftaps.com/opentaps/control/main");
	driver.manage().window().maximize();
	driver.get(url);
	driver.findElement(By.id("username")).sendKeys("Demosalesmanager");
    driver.findElement(By.name("PASSWORD")).sendKeys("crmsfa");
	driver.findElement(By.className("decorativeSubmit")).click();
	}
@AfterMethod
public void PostCondition() {
	
}
}
