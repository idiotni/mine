package week5day2;

public class TestNg {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
