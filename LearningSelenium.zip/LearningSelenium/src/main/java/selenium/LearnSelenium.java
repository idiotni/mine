package selenium;



import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class LearnSelenium {

	public static void main(String[] args) {
	
		System.setProperty("webdriver.chrome.driver","./Src/main/resources/drivers/chromedriver.exe");
		// TODO Auto-generated method stub
ChromeDriver driver =new ChromeDriver();
driver.get("http://leaftaps.com/opentaps/control/main");
driver.manage().window().maximize();
WebElement elementUsername= driver.findElement(By.id("username"));
elementUsername.sendKeys("Demosalesmanager");
driver.findElement(By.name("PASSWORD")).sendKeys("crmsfa");
driver.findElement(By.className("decorativeSubmit")).click();
driver.findElement(By.partialLinkText("CRM/SFA")).click();
driver.findElement(By.linkText("Contacts")).click();
driver.findElement(By.linkText("Create Contact")).click();
WebElement elementFirstName=driver.findElement(By.id("firstNameField"));
elementFirstName.sendKeys("Sumithra");
driver.findElement(By.id("lastNameField")).sendKeys("s");
driver.findElement(By.name("submitButton")).click();
driver.close();



	}

}
