import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class ServiceNow {
	
	public static void main(String[] args) {
		WebDriverManager.chromedriver().setup();
		ChromeDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://docs.servicenow.com/");
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
		driver.findElement(By.id("login")).click();
		driver.findElement(By.id("username")).sendKeys("sumithrashan97@gmail.com");
		driver.findElement(By.id("usernameSubmitButton")).click();
		driver.findElement(By.id("password")).sendKeys("Sumithra@97");
		driver.findElement(By.id("submitButton")).click();
		driver.findElement(By.xpath("//input[@class='search__field ui-autocomplete-input']")).sendKeys("incident");
		
		/*Step1: Load ServiceNow application URL 
		Step2: Enter username (Check for frame before entering the username)
		Step3: Enter password 
		Step4: Click Login
		Step5: Search �incident � Filter Navigator
		Step6: Click �All�
		Step7: Click New button
		Step8: Select a value for Caller and Enter value for short_description
		Step9: Read the incident number and save it a variable
		Step10: Click on Submit button
		Step 11: Search the same incident number in the next search screen as below
		Step12: Verify the incident is created successful and take snapshot of the created incident.*/
	}
}