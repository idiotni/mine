package week1.day1;
public class OddNumbers {
	public static void main(String[]args) {
		System.out.println("the odd no is");
		for (int i=0;i<=100;i++) {
			if(i%2 !=0) {
				System.out.println(i);
			}
			
		}
	}

		

}
