package week1.day1;

public class EvenNo{
	public static void main(String[]args) {
		System.out.println("the even no is");
		for (int i=59;i>=38;i--) {
			if(i%2==0){
				System.out.println(i*i);
}
	}
	}
}

