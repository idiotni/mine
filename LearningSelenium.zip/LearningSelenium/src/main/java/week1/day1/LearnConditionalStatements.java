package week1.day1;

public class LearnConditionalStatements {
	public static void main(String[]args) {
		int age=21;
		if (age>=18) {
			System.out.println("the canditate is eligible for voting");
		}
		else{
			System.out.println("the canditate is eligible for voting");
		}
	}

	public LearnConditionalStatements() {
		// TODO Auto-generated constructor stub
	}

}
