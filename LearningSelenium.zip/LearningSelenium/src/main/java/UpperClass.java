
public class UpperClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
String test="name change";

String uppercase =test.toUpperCase();

		System.out.println(uppercase);
	}
	

	}


