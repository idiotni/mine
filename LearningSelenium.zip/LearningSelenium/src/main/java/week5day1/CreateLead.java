package week5day1;
import org.openqa.selenium.By;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
// establishing a data into this method
@Test(dataProvider= "SendData")
public class CreateLead extends Baseclass {
	public void createLead (String cName,String fName,String lName) {
		driver.findElement(By.linkText("Leads")).click();
		driver.findElement(By.linkText("Create Lead")).click();
		driver.findElement(By.id("createLeadForm_companyName")).sendKeys(cName);
		driver.findElement(By.id("createLeadForm_firstName")).sendKeys(fName);
		driver.findElement(By.id("createLeadForm_lastName")).sendKeys(lName);
		/*driver.findElement(By.id("createLeadForm_birthDate")).sendKeys("9/5/1997");
		driver.findElement(By.id("createLeadForm_primaryEmail")).sendKeys("babu@testleaf.com");
		driver.findElement(By.id("createLeadForm_primaryPhoneNumber")).sendKeys("123456789");
		driver.findElement(By.id("createLeadForm_primaryPhoneAskForName")).sendKeys("ari");
		driver.findElement(By.id("createLeadForm_primaryWebUrl")).sendKeys("google.com");
		driver.findElement(By.id("createLeadForm_generalToName")).sendKeys("Anu");
		driver.findElement(By.id("createLeadForm_generalAttnName")).sendKeys("vaishu");
		driver.findElement(By.id("createLeadForm_generalAddress1")).sendKeys("27,kamaraj salai");
		driver.findElement(By.id("createLeadForm_generalAddress2")).sendKeys("sree nagar nagar");
		driver.findElement(By.id("createLeadForm_generalCity")).sendKeys("Chennai");
		driver.findElement(By.id("createLeadForm_generalStateProvinceGeoId")).sendKeys("Tennessee");
		driver.findElement(By.id("createLeadForm_generalPostalCode")).sendKeys("600062");
		driver.findElement(By.name("submitButton")).click();*/
	}
	@DataProvider
	public String[][] SendData() {
		String [] [] data = new String [3] [4];
		data[1][1]="TestLeaf";
		data[1][2]="Sumithra";
		data[1][3]="S";

		data[1][1]="Qeagle";
		data[1][2]="Haahana";
		data[1][3]="R";

		return data;		
	}


}



