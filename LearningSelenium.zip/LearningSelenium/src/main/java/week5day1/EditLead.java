package week5day1;

import org.openqa.selenium.By;

import org.testng.annotations.Test;
public class EditLead extends Baseclass{
	@Test
	public void editLead() {
	driver.findElement(By.linkText("Leads")).click();
	driver.findElement(By.linkText("Find Leads")).click();
	driver.findElement(By.name("firstName")).sendKeys("shree");
	driver.findElement(By.xpath("//button[text()='Find Leads']")).click();
	driver.findElement(By.xpath("(//a[@href='/crmsfa/control/viewLead?partyId=10120'])")).click();
    driver.findElement(By.xpath("//a[text()='Edit']")).click();
	driver.findElement(By.id("updateLeadForm_companyName")).clear();
	driver.findElement(By.id("updateLeadForm_companyName")).sendKeys("TestLeaf");
	driver.findElement(By.name("submitButton")).click();
	driver.close();
	}	
}
