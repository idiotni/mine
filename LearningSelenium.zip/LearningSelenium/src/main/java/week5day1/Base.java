package week5day1;

public class Base {

}
