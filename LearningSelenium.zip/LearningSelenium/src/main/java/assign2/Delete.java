package assign2;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class Delete {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		WebDriverManager.chromedriver().setup();
		ChromeDriver driver=new ChromeDriver();
		driver.get("http://leaftaps.com/opentaps/control/main");
		driver.manage().window().maximize();
		WebElement elementUsername=driver.findElement(By.id("username"));
		elementUsername.sendKeys("Demosalesmanager");
		driver.findElement(By.name("PASSWORD")).sendKeys("crmsfa");
		driver.findElement(By.className("decorativeSubmit")).click();
		driver.findElement(By.linkText("CRM/SFA")).click();
	   driver.findElement(By.linkText("Leads")).click();
	   driver.findElement(By.linkText("Find Leads")).click();
	   driver.findElement(By.linkText("Phone")).click();
	   driver.findElement(By.name("phoneNumber")).sendKeys("123456");
	   driver.findElement(By.xpath("//button[@id='ext-gen334']")).click();
		WebElement leadID = driver.findElement(By.xpath("(//div[@class='x-grid3-cell-inner x-grid3-col-partyId'])[1]/a"));
		String leadIDText = leadID.getText();
		//driver.findElement(By.xpath("//div[@class='x-grid3-cell-inner x-grid3-col-firstName']//a")).click();
	   driver.findElement(By.className("subMenuButtonDangerous")).click();
	   driver.findElement(By.linkText("Find Leads")).click();
/*	10	Click find leads button
			driver.findElement(By.xpath("//button[contains(text(), 'Find Leads')]")).click();
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			Thread.sleep(5000);
//		11	Capture lead ID of First Resulting lead
				WebElement leadID = driver.findElement(By.xpath("(//div[@class='x-grid3-cell-inner x-grid3-col-partyId'])[1]/a"));
			String leadIDText = leadID.getText();
			// System.out.println(leadIDText);		 = driver.findElement(By.xpath("(//div[@class='x-grid3-cell-inner x-grid3-col-partyId'])[1]/a"));
			String leadIDText = leadID.getText();
			// System.out.println(leadIDText);		
//		12	Click First Resulting lead
			leadID.click();
			Thread.sleep(5000);
//		13	Click Delete
			driver.findElement(By.className("subMenuButtonDangerous")).click();
//		14	Click Find leads
			driver.findElement(By.linkText("Find Leads")).click();
//		15	Enter captured lead ID
			driver.findElement(By.name("id")).sendKeys(leadIDText);
//		16	Click find leads button
			driver.findElement(By.xpath("//button[contains(text(), 'Find Leads')]")).click();
//		17	Verify message "No records to display" in the Lead List. This message confirms the successful deletion
			if (driver.findElement(By.className("x-paging-info")).isDisplayed()) {
				System.out.println("No records to display is getting printed");
			} else {
				System.out.println("There are records to display");
			}
//		18	Close the browser (Do not log out)
			driver.close();*/
	}
}
