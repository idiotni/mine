package org.College;

public class College {
    public void collegeName() {
       System.out.println("Priyardarshini Engineering College");
} 
	public void collegeCode() {
		System.out.println("1502");
}
	public void collegeRank() {
		System.out.println("above 100");
}
}