package org.Dept;

public class Department {
	public void deptName() {
		System.out.println("ELECTRICAL AND ELECTRICAL ELECTRONICS");
}
}
