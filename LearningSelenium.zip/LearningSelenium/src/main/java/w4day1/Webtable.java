package w4day1;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import java.util.List;


import io.github.bonigarcia.wdm.WebDriverManager;


public class Webtable {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		WebDriverManager.chromedriver().setup();
		ChromeDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://erail.in/");
		WebElement from= driver.findElement(By.id("txtStationFrom"));
	    from.clear();
	    from.sendKeys("TPJ",Keys.TAB);
	    WebElement to= driver.findElement(By.id("txtStationto"));
	    to.clear();
	    to.sendKeys("MDU",Keys.TAB);
	    driver.findElement(By.id("chkSelectDateOnly")).click();
	    //finding element through a locator
	   WebElement elementTable=driver.findElement(By.xpath("//table[@class='DataTable TrainList TrainListHeader']"));
	   //finding the row from the table we found
	   List<WebElement> listRows=elementTable.findElements(By.tagName("tr"));
	    //iterate rows form the table
	    //finding the table we are storing the table
	    for(int i=0;i<listRows.size();i++) {
	     WebElement currentRow=listRows.get(i);
	    List<WebElement> listcolumns=currentRow.findElements(By.tagName("td"));
	    //iterate coloumns form the table
	    for(int j=0;j<listcolumns.size();j++) {
	    System.out.println(listcolumns.get(j).getText());
	    }
	    }
	
	}

}
